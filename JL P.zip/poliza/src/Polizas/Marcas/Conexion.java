package Polizas.Marcas;


public class Conexion extends Polizas.General.Conexion {

    
    public Conexion() {
        super();
    }
}
