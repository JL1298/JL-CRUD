package Polizas.Marcas;

import java.sql.SQLException;
import java.util.List;
import java.util.ArrayList;
import Polizas.General.Conexion;
import Polizas.General.DAO;

public class MarcasModelo extends Conexion implements DAO {

    MarcasModelo() {
        super();
    }

    public boolean existeMarca(String nombre) {
        try {
            this.conectar();
            if (cnx == null) {
                return false;
            }
            ps = cnx.prepareStatement("SELECT COUNT(*) FROM marca WHERE LOWER(TRIM(nombreMarca)) = LOWER(TRIM(?))");
            ps.setString(1, nombre);
            rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        } catch (SQLException ex) {
            System.out.println("Error al verificar existencia: " + ex.getMessage());
        } finally {
            this.close();
        }
        return false;
    }

    @Override
    public List read() {
        List<Marca> lista = new ArrayList<>();
        try {
            this.conectar();
            if (cnx == null) {
                return lista;
            }
            ps = cnx.prepareStatement("SELECT idMarca, nombreMarca FROM marca");
            rs = ps.executeQuery();
            lista.clear();

            while (rs.next()) {
                lista.add(new Marca(rs.getInt("idMarca"), rs.getString("nombreMarca")));
            }
        } catch (SQLException ex) {
            System.out.println("Error: " + ex.getMessage());
        } finally {
            this.close();
        }
        return lista;
    }

    @Override
    public int create(Object obj) {
        try {
            this.conectar();
            if (cnx == null) {
                return 0;
            }
            Marca marca = (Marca) obj;
            ps = cnx.prepareStatement("INSERT INTO marca(nombreMarca) VALUES (?)");
            ps.setString(1, marca.getNombre().trim());
            return ps.executeUpdate();
        } catch (SQLException ex) {
            System.out.println("Error " + ex.getMessage());
            return 0;
        } finally {
            this.close();
        }
    }

    @Override
    public int delete(Object obj) {
        try {
            this.conectar();
            if (cnx == null) {
                return 0;
            }
            Marca marca = (Marca) obj;
            ps = cnx.prepareStatement("DELETE FROM marca WHERE idMarca = ?");
            ps.setInt(1, marca.getId());
            return ps.executeUpdate();
        } catch (SQLException ex) {
            System.out.println("Error " + ex.getMessage());
            return 0;
        } finally {
            this.close();
        }
    }

    @Override
    public int update(Object lista) {
        try {
            this.conectar();
            if (cnx == null) {
                return 0;
            }
            Marca marca = (Marca) lista;
            ps = cnx.prepareStatement("UPDATE marca SET nombreMarca = ? WHERE idMarca = ?");
            ps.setString(1, marca.getNombre().trim());
            ps.setInt(2, marca.getId());
            return ps.executeUpdate();
        } catch (SQLException ex) {
            System.out.println("Error " + ex.getMessage());
            return 0;
        } finally {
            this.close();
        }
    }
}
