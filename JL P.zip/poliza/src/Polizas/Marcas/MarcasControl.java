package Polizas.Marcas;

import java.awt.event.MouseAdapter;
import java.util.List;
import javax.swing.JOptionPane;

public class MarcasControl {

    private MarcasVista mv;
    private MarcasModelo mm;
    private List<Marca> lista;

    public MarcasControl(MarcasVista marcasVista) {
        this.mv = marcasVista;
        this.mm = new MarcasModelo();

        marcasEventos();
        mv.actualizarVista(mm.read());
    }

    public void marcasEventos() {

        mv.btn1.addActionListener(e -> {
            lista = mm.read();
            mv.actualizarVista(lista);
        });

        mv.btn_a.addActionListener(e -> {
            String nombre = mv.txt1.getText().trim();

            if (nombre.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Escribe el nombre de la marca");
                return;
            }

            if (mm.existeMarca(nombre)) {
                JOptionPane.showMessageDialog(null, "La marca \"" + nombre + "\" ya se encuentra registrada");
                return;
            }

            Object marca = new Marca(0, nombre);
            int resultado = mm.create(marca);
            JOptionPane.showMessageDialog(null, resultado == 1 ? "Marca registrada" : "No se pudo registrar");

            if (resultado == 1) {
                mv.txt1.setText("");
            }
            mv.actualizarVista(mm.read());
        });

        mv.btn_u.addActionListener(e -> {
            int fila = mv.tabla.getSelectedRow();
            if (fila < 0) {
                JOptionPane.showMessageDialog(null, "Selecciona una marca de la tabla");
                return;
            }

            String nombre = mv.txt1.getText().trim();
            if (nombre.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Escribe el nuevo nombre de la marca");
                return;
            }

            Marca seleccionada = mv.marcasModelo.getMarca(fila);

            if (!seleccionada.getNombre().equalsIgnoreCase(nombre) && mm.existeMarca(nombre)) {
                JOptionPane.showMessageDialog(null, "Ya existe otra marca con el nombre \"" + nombre + "\"");
                return;
            }

            Object marca = new Marca(seleccionada.getId(), nombre);
            int resultado = mm.update(marca);
            JOptionPane.showMessageDialog(null, resultado == 1 ? "Marca actualizada" : "No se pudo actualizar");

            if (resultado == 1) {
                mv.txt1.setText("");
            }
            mv.actualizarVista(mm.read());
        });
        
        mv.btn_e.addActionListener(e -> {
            int fila = mv.tabla.getSelectedRow();
            if (fila < 0) {
                JOptionPane.showMessageDialog(null, "Selecciona una marca de la tabla");
                return;
            }
            Marca seleccionada = mv.marcasModelo.getMarca(fila);
            int opcion = JOptionPane.showConfirmDialog(null,
                    "¿Eliminar la marca \"" + seleccionada.getNombre() + "\"?",
                    "Confirmar", JOptionPane.YES_NO_OPTION);
            if (opcion != JOptionPane.YES_OPTION) {
                return;
            }
            int resultado = mm.delete(seleccionada);
            JOptionPane.showMessageDialog(null,
                    resultado == 1 ? "Marca eliminada" : "No se pudo eliminar");

            if (resultado == 1) {
                mv.txt1.setText("");
            }
            mv.actualizarVista(mm.read());
        });

        mv.tabla.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(java.awt.event.MouseEvent e) {
                int fila = mv.tabla.getSelectedRow();
                if (fila >= 0) {
                    System.out.println("Registro: " + mv.marcasModelo.getValueAt(fila, 1));
                    mv.txt1.setText((String) mv.marcasModelo.getValueAt(fila, 1));
                }
            }
        });

        mv.tabla.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                int fila = mv.tabla.getSelectedRow();
                if (fila >= 0) {
                    System.out.println("Registro: " + fila + " Valor: " + mv.tabla.getValueAt(fila, 1));
                }
            }
        });

        mv.cmbMarcas.addActionListener(e -> {
            Marca marca = (Marca) mv.cmbMarcas.getSelectedItem();
        });
    }
}
